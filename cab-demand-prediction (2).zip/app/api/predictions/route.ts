import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

export async function GET(req: NextRequest) {
  try {
    const sql = neon(process.env.DATABASE_URL!)

    // Fetch recent predictions for all zones
    const predictions = await sql`
      SELECT 
        zone_id,
        predicted_demand,
        predicted_surge_multiplier,
        confidence_score,
        prediction_time
      FROM demand_predictions
      WHERE prediction_time >= NOW() - INTERVAL '24 hours'
      ORDER BY zone_id, prediction_time DESC
    `

    return NextResponse.json(predictions)
  } catch (error) {
    console.error("Predictions fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch predictions" }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const { zone_id, predicted_demand, predicted_surge_multiplier, confidence_score } = await req.json()
    const sql = neon(process.env.DATABASE_URL!)

    await sql`
      INSERT INTO demand_predictions 
      (zone_id, prediction_time, predicted_demand, predicted_surge_multiplier, confidence_score)
      VALUES (${zone_id}, NOW(), ${predicted_demand}, ${predicted_surge_multiplier}, ${confidence_score})
    `

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Prediction save error:", error)
    return NextResponse.json({ error: "Failed to save prediction" }, { status: 500 })
  }
}
