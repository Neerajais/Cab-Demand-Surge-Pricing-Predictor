import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

export async function GET(req: NextRequest) {
  try {
    const sql = neon(process.env.DATABASE_URL!)

    // Fetch all zones with recent demand data
    const zones = await sql`
      SELECT 
        az.zone_id,
        az.zone_name,
        az.latitude,
        az.longitude,
        az.area_category,
        COUNT(rd.id) as recent_rides,
        COALESCE(AVG(rd.surge_multiplier), 1.0) as avg_surge
      FROM area_zones az
      LEFT JOIN ride_data rd ON az.zone_id = rd.pickup_zone_id 
        AND rd.pickup_time >= NOW() - INTERVAL '1 hour'
      GROUP BY az.zone_id, az.zone_name, az.latitude, az.longitude, az.area_category
      ORDER BY recent_rides DESC
    `

    return NextResponse.json(zones)
  } catch (error) {
    console.error("Zones fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch zones" }, { status: 500 })
  }
}
