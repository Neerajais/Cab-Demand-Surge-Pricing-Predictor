import DashboardPage from "@/components/dashboard"

export const metadata = {
  title: "Cab Demand & Surge Pricing Predictor",
  description: "Real-time demand forecasting and surge pricing analysis",
}

export default function Home() {
  return <DashboardPage />
}
