"use client"

import { useMemo } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
  Area,
  AreaChart,
} from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CancellationPrediction() {
  const highRiskRides = [
    {
      rideId: "R-19845",
      zone: "Majestic",
      probability: 0.87,
      factors: ["high_surge", "late_night", "rain"],
      fare: 456,
      surge: 2.1,
    },
    {
      rideId: "R-20112",
      zone: "MG Road",
      probability: 0.79,
      factors: ["long_distance", "peak_hour"],
      fare: 312,
      surge: 1.8,
    },
    {
      rideId: "R-18923",
      zone: "Koramangala",
      probability: 0.74,
      factors: ["high_surge", "weekend"],
      fare: 289,
      surge: 1.6,
    },
    {
      rideId: "R-21045",
      zone: "Whitefield",
      probability: 0.71,
      factors: ["traffic", "late_night"],
      fare: 198,
      surge: 1.4,
    },
    { rideId: "R-19567", zone: "Jayanagar", probability: 0.68, factors: ["rain", "long_wait"], fare: 245, surge: 1.5 },
  ]

  const cancellationRateByZone = useMemo(
    () => [
      { zone: "Majestic", rate: 16.8, count: 198, color: "#ef4444" },
      { zone: "MG Road", rate: 13.1, count: 186, color: "#f97316" },
      { zone: "Whitefield", rate: 10.8, count: 142, color: "#f97316" },
      { zone: "Koramangala", rate: 8.0, count: 127, color: "#eab308" },
      { zone: "Jayanagar", rate: 10.7, count: 112, color: "#eab308" },
      { zone: "Indiranagar", rate: 6.0, count: 98, color: "#22c55e" },
      { zone: "Hebbal", rate: 9.1, count: 89, color: "#22c55e" },
      { zone: "Brookefield", rate: 8.5, count: 78, color: "#22c55e" },
      { zone: "Yelahanka", rate: 7.5, count: 67, color: "#06b6d4" },
      { zone: "Airport", rate: 2.5, count: 52, color: "#06b6d4" },
    ],
    [],
  )

  const riskDistribution = useMemo(
    () => [
      { name: "High Risk (>70%)", value: 23, fill: "#ef4444" },
      { name: "Medium Risk (40-70%)", value: 41, fill: "#f97316" },
      { name: "Low Risk (<40%)", value: 36, fill: "#22c55e" },
    ],
    [],
  )

  const timeOfDayRisks = useMemo(
    () => [
      { hour: "00:00", risk: 0.72, cancellations: 45 },
      { hour: "02:00", risk: 0.78, cancellations: 38 },
      { hour: "04:00", risk: 0.65, cancellations: 22 },
      { hour: "06:00", risk: 0.35, cancellations: 28 },
      { hour: "08:00", risk: 0.48, cancellations: 67 },
      { hour: "10:00", risk: 0.32, cancellations: 41 },
      { hour: "12:00", risk: 0.28, cancellations: 35 },
      { hour: "14:00", risk: 0.31, cancellations: 38 },
      { hour: "16:00", risk: 0.42, cancellations: 52 },
      { hour: "18:00", risk: 0.58, cancellations: 89 },
      { hour: "20:00", risk: 0.67, cancellations: 76 },
      { hour: "22:00", risk: 0.75, cancellations: 58 },
    ],
    [],
  )

  const getRiskColor = (prob: number) => {
    if (prob >= 0.75) return "text-red-400 bg-red-500/20 border-red-500/50"
    if (prob >= 0.6) return "text-orange-400 bg-orange-500/20 border-orange-500/50"
    return "text-yellow-400 bg-yellow-500/20 border-yellow-500/50"
  }

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900/90 border-slate-700 backdrop-blur">
        <CardHeader className="pb-3">
          <CardTitle className="text-pink-400 text-xl">Ride Cancellation Prediction</CardTitle>
          <CardDescription className="text-slate-400">
            ML-powered predictions using Logistic Regression, Random Forest & XGBoost ensemble
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="risks" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-slate-800/80 border border-slate-700 p-1 rounded-lg">
              <TabsTrigger
                value="risks"
                className="data-[state=active]:bg-red-500 data-[state=active]:text-white text-xs rounded-md"
              >
                High Risk
              </TabsTrigger>
              <TabsTrigger
                value="zones"
                className="data-[state=active]:bg-pink-500 data-[state=active]:text-white text-xs rounded-md"
              >
                By Zone
              </TabsTrigger>
              <TabsTrigger
                value="distribution"
                className="data-[state=active]:bg-orange-500 data-[state=active]:text-white text-xs rounded-md"
              >
                Distribution
              </TabsTrigger>
              <TabsTrigger
                value="timeline"
                className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black text-xs rounded-md"
              >
                Time Pattern
              </TabsTrigger>
            </TabsList>

            {/* High Risk Rides Tab */}
            <TabsContent value="risks" className="mt-6">
              <div className="space-y-3">
                {highRiskRides.map((ride, idx) => (
                  <div
                    key={ride.rideId}
                    className={`p-4 rounded-xl border transition-all hover:scale-[1.01] ${getRiskColor(ride.probability)}`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-bold text-lg">{ride.rideId}</p>
                        <p className="text-sm text-slate-300">{ride.zone}</p>
                        <p className="text-xs text-slate-400 mt-1">
                          Fare: ₹{ride.fare} | Surge: {ride.surge}x
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-3xl font-black">{(ride.probability * 100).toFixed(0)}%</p>
                        <p className="text-xs text-slate-400">Cancel Risk</p>
                      </div>
                    </div>
                    <div className="mt-3 flex gap-2 flex-wrap">
                      {ride.factors.map((factor) => (
                        <span
                          key={factor}
                          className="px-2 py-1 text-xs bg-black/30 rounded-full border border-white/10"
                        >
                          {factor.replace("_", " ")}
                        </span>
                      ))}
                    </div>
                    {/* Risk bar */}
                    <div className="mt-3 h-2 bg-black/30 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 rounded-full transition-all"
                        style={{ width: `${ride.probability * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="zones" className="mt-6">
              <ResponsiveContainer width="100%" height={420}>
                <BarChart
                  data={cancellationRateByZone}
                  layout="vertical"
                  margin={{ top: 10, right: 30, left: 80, bottom: 10 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={true} vertical={false} />
                  <XAxis
                    type="number"
                    stroke="#94a3b8"
                    tick={{ fill: "#94a3b8" }}
                    domain={[0, 20]}
                    label={{ value: "Cancellation Rate (%)", position: "insideBottom", offset: -5, fill: "#94a3b8" }}
                  />
                  <YAxis
                    dataKey="zone"
                    type="category"
                    width={75}
                    stroke="#94a3b8"
                    tick={{ fontSize: 11, fill: "#94a3b8" }}
                    axisLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #ec4899",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                    formatter={(value, name, props) => {
                      if (name === "rate") {
                        return [`${value}% (${props.payload.count} rides)`, "Cancel Rate"]
                      }
                      return [value, name]
                    }}
                  />
                  <Bar dataKey="rate" radius={[0, 8, 8, 0]} barSize={20}>
                    {cancellationRateByZone.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>

              {/* Zone insights */}
              <div className="mt-4 grid grid-cols-2 md:grid-cols-5 gap-3">
                {cancellationRateByZone.slice(0, 5).map((zone) => (
                  <div key={zone.zone} className="p-3 bg-slate-800/60 rounded-lg border border-slate-700 text-center">
                    <p className="text-xs text-slate-400 truncate">{zone.zone}</p>
                    <p className="text-xl font-bold" style={{ color: zone.color }}>
                      {zone.rate}%
                    </p>
                    <p className="text-xs text-slate-500">{zone.count} cancelled</p>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Distribution Pie Chart */}
            <TabsContent value="distribution" className="mt-6">
              <div className="flex flex-col lg:flex-row items-center justify-center gap-8">
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={riskDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${value}%`}
                      outerRadius={100}
                      innerRadius={60}
                      fill="#8884d8"
                      dataKey="value"
                      paddingAngle={2}
                    >
                      {riskDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} stroke="none" />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#1e293b",
                        border: "1px solid #475569",
                        borderRadius: "8px",
                        color: "#e2e8f0",
                      }}
                    />
                    <Legend
                      verticalAlign="bottom"
                      height={36}
                      formatter={(value) => <span className="text-slate-300 text-sm">{value}</span>}
                    />
                  </PieChart>
                </ResponsiveContainer>

                {/* Summary stats */}
                <div className="space-y-4 min-w-[200px]">
                  <div className="p-4 bg-red-500/10 rounded-lg border border-red-500/30">
                    <p className="text-red-400 text-3xl font-black">23%</p>
                    <p className="text-slate-400 text-sm">High Risk Rides</p>
                  </div>
                  <div className="p-4 bg-orange-500/10 rounded-lg border border-orange-500/30">
                    <p className="text-orange-400 text-3xl font-black">41%</p>
                    <p className="text-slate-400 text-sm">Medium Risk</p>
                  </div>
                  <div className="p-4 bg-green-500/10 rounded-lg border border-green-500/30">
                    <p className="text-green-400 text-3xl font-black">36%</p>
                    <p className="text-slate-400 text-sm">Low Risk</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Time Pattern */}
            <TabsContent value="timeline" className="mt-6">
              <ResponsiveContainer width="100%" height={350}>
                <AreaChart data={timeOfDayRisks} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <defs>
                    <linearGradient id="riskGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f97316" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#f97316" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="hour" stroke="#94a3b8" tick={{ fill: "#94a3b8", fontSize: 11 }} />
                  <YAxis
                    stroke="#94a3b8"
                    tick={{ fill: "#94a3b8" }}
                    domain={[0, 1]}
                    tickFormatter={(v) => `${(v * 100).toFixed(0)}%`}
                    label={{ value: "Risk Score", angle: -90, position: "insideLeft", fill: "#94a3b8" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #f97316",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                    formatter={(value, name) => {
                      if (name === "risk") return [`${(Number(value) * 100).toFixed(0)}%`, "Cancel Risk"]
                      return [value, "Cancellations"]
                    }}
                  />
                  <Area type="monotone" dataKey="risk" stroke="#f97316" strokeWidth={3} fill="url(#riskGradient)" />
                  <Line
                    type="monotone"
                    dataKey="risk"
                    stroke="#f97316"
                    strokeWidth={2}
                    dot={{ fill: "#f97316", strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, fill: "#fff", stroke: "#f97316" }}
                  />
                </AreaChart>
              </ResponsiveContainer>

              {/* Time insights */}
              <div className="mt-4 p-4 bg-gradient-to-r from-orange-500/10 to-yellow-500/10 rounded-lg border border-orange-500/30">
                <h4 className="text-orange-400 font-semibold mb-2">Peak Risk Hours</h4>
                <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                    <span className="text-slate-300">Late Night (10PM - 2AM): 72-78% risk</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-orange-500 rounded-full"></span>
                    <span className="text-slate-300">Evening Rush (6PM - 8PM): 58-67% risk</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                    <span className="text-slate-300">Mid-Day (10AM - 2PM): 28-32% risk</span>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
