"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import HeatmapVisualization from "./heatmap-visualization"
import DemandForecast from "./demand-forecast"
import AnalyticsSummary from "./analytics-summary"
import GeoSpatialMap from "./geo-spatial-map"
import CancellationPrediction from "./cancellation-prediction"
import SurgeForecasting from "./surge-forecasting"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-2">
          Cab Demand & Surge Pricing Predictor
        </h1>
        <p className="text-gray-400">Real-time demand forecasting and surge pricing analysis powered by ML models</p>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-gray-900 border border-gray-800 grid grid-cols-6 w-full">
          <TabsTrigger
            value="overview"
            className="text-gray-300 data-[state=active]:text-cyan-400 data-[state=active]:bg-gray-800"
          >
            Dashboard
          </TabsTrigger>
          <TabsTrigger
            value="forecast"
            className="text-gray-300 data-[state=active]:text-cyan-400 data-[state=active]:bg-gray-800"
          >
            Demand Forecast
          </TabsTrigger>
          <TabsTrigger
            value="heatmap"
            className="text-gray-300 data-[state=active]:text-cyan-400 data-[state=active]:bg-gray-800"
          >
            Heatmap
          </TabsTrigger>
          <TabsTrigger
            value="geo"
            className="text-gray-300 data-[state=active]:text-cyan-400 data-[state=active]:bg-gray-800"
          >
            Geo-Spatial
          </TabsTrigger>
          <TabsTrigger
            value="cancellation"
            className="text-gray-300 data-[state=active]:text-pink-400 data-[state=active]:bg-gray-800"
          >
            Cancellations
          </TabsTrigger>
          <TabsTrigger
            value="surge"
            className="text-gray-300 data-[state=active]:text-purple-400 data-[state=active]:bg-gray-800"
          >
            Surge Forecast
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <AnalyticsSummary />
        </TabsContent>

        {/* Forecast Tab */}
        <TabsContent value="forecast" className="space-y-6">
          <DemandForecast />
        </TabsContent>

        {/* Heatmap Tab */}
        <TabsContent value="heatmap" className="space-y-6">
          <HeatmapVisualization />
        </TabsContent>

        {/* Geo-Spatial Analysis Tab */}
        <TabsContent value="geo" className="space-y-6">
          <GeoSpatialMap />
        </TabsContent>

        {/* Cancellation Prediction Tab */}
        <TabsContent value="cancellation" className="space-y-6">
          <CancellationPrediction />
        </TabsContent>

        {/* Surge Forecasting Tab */}
        <TabsContent value="surge" className="space-y-6">
          <SurgeForecasting />
        </TabsContent>
      </Tabs>
    </div>
  )
}
