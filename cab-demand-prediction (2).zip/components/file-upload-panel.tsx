"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function FileUploadPanel() {
  const [uploadedFiles, setUploadedFiles] = useState<{ areas: boolean; rides: boolean }>({
    areas: false,
    rides: false,
  })
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState("")

  const handleFileUpload = async (file: File, fileType: "areas" | "rides") => {
    if (!file) return

    setIsLoading(true)
    const formData = new FormData()
    formData.append("file", file)
    formData.append("type", fileType)

    try {
      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      const responseData = await response.json()

      if (response.ok) {
        setUploadedFiles((prev) => ({ ...prev, [fileType]: true }))
        setMessage(`${fileType === "areas" ? "Area zones" : "Ride data"} uploaded successfully!`)
        setTimeout(() => setMessage(""), 3000)
      } else {
        const errorMsg = responseData.details || responseData.error || "Upload failed"
        setMessage(`Error: ${errorMsg}`)
        console.error("[v0] Upload response error:", responseData)
      }
    } catch (error) {
      setMessage("Error uploading file.")
      console.error("[v0] Upload error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-cyan-400">Upload Data Files</CardTitle>
          <CardDescription>Upload CSV files for area zones and ride data</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {message && (
            <div
              className={`p-4 rounded-lg ${message.includes("successfully") ? "bg-green-900 text-green-200" : "bg-red-900 text-red-200"}`}
            >
              {message}
            </div>
          )}

          {/* Area Zones Upload */}
          <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center hover:border-cyan-500 transition-colors">
            <p className="text-gray-300 font-semibold mb-4">Area Zones CSV</p>
            <p className="text-gray-500 text-sm mb-4">
              Expected columns: zone_id, zone_name, latitude, longitude, area_category
            </p>
            <label className="inline-block">
              <input
                type="file"
                accept=".csv"
                onChange={(e) => e.target.files && handleFileUpload(e.target.files[0], "areas")}
                disabled={isLoading}
                className="hidden"
              />
              <Button
                asChild
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 cursor-pointer"
                disabled={isLoading}
              >
                <span>{uploadedFiles.areas ? "✓ Uploaded" : "Choose File"}</span>
              </Button>
            </label>
          </div>

          {/* Ride Data Upload */}
          <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center hover:border-pink-500 transition-colors">
            <p className="text-gray-300 font-semibold mb-4">Ride Data CSV</p>
            <p className="text-gray-500 text-sm mb-4">
              Expected columns: pickup_datetime, dropoff_datetime, pickup_zone, dropoff_zone, fare, surge_multiplier
            </p>
            <label className="inline-block">
              <input
                type="file"
                accept=".csv"
                onChange={(e) => e.target.files && handleFileUpload(e.target.files[0], "rides")}
                disabled={isLoading}
                className="hidden"
              />
              <Button
                asChild
                className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 cursor-pointer"
                disabled={isLoading}
              >
                <span>{uploadedFiles.rides ? "✓ Uploaded" : "Choose File"}</span>
              </Button>
            </label>
          </div>

          {/* Info */}
          <div className="bg-gray-800 p-4 rounded-lg">
            <p className="text-gray-300 text-sm">
              <strong>Note:</strong> After uploading, the system will automatically process the data and train the ML
              model for demand predictions.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
