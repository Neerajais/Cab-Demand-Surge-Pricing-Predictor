"use client"

import { useMemo } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  Cell,
  ZAxis,
} from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function GeoSpatialMap() {
  const hotspots = [
    { zone: "Koramangala", lat: 12.9352, lon: 77.6245, intensity: 85, cancellations: 127, rides: 1580 },
    { zone: "Indiranagar", lat: 12.9716, lon: 77.6412, intensity: 92, cancellations: 98, rides: 1640 },
    { zone: "MG Road", lat: 12.9752, lon: 77.6066, intensity: 88, cancellations: 186, rides: 1420 },
    { zone: "Whitefield", lat: 12.9698, lon: 77.7499, intensity: 78, cancellations: 142, rides: 1320 },
    { zone: "Yelahanka", lat: 13.0859, lon: 77.5974, intensity: 65, cancellations: 67, rides: 890 },
    { zone: "Majestic", lat: 12.977, lon: 77.5773, intensity: 82, cancellations: 198, rides: 1180 },
    { zone: "Hebbal", lat: 13.0358, lon: 77.597, intensity: 72, cancellations: 89, rides: 980 },
    { zone: "Jayanagar", lat: 12.9299, lon: 77.5826, intensity: 68, cancellations: 112, rides: 1050 },
    { zone: "Brookefield", lat: 12.9698, lon: 77.7166, intensity: 76, cancellations: 78, rides: 920 },
    { zone: "Airport", lat: 13.1986, lon: 77.7066, intensity: 95, cancellations: 52, rides: 2100 },
  ]

  const cancellationByZone = useMemo(() => {
    return hotspots
      .map((h) => ({
        zone: h.zone,
        cancellations: h.cancellations,
        rate: ((h.cancellations / h.rides) * 100).toFixed(1),
      }))
      .sort((a, b) => b.cancellations - a.cancellations)
  }, [])

  const intensityData = useMemo(() => {
    return hotspots
      .map((h) => ({
        zone: h.zone,
        intensity: h.intensity,
        rides: h.rides,
      }))
      .sort((a, b) => b.intensity - a.intensity)
  }, [])

  const scatterData = useMemo(() => {
    return hotspots.map((h) => ({
      x: h.lon,
      y: h.lat,
      z: h.intensity * 2,
      zone: h.zone,
      cancellations: h.cancellations,
      intensity: h.intensity,
      rides: h.rides,
    }))
  }, [])

  const getIntensityColor = (intensity: number) => {
    if (intensity >= 90) return "#ef4444"
    if (intensity >= 80) return "#f97316"
    if (intensity >= 70) return "#eab308"
    if (intensity >= 60) return "#22c55e"
    return "#06b6d4"
  }

  const COLORS = [
    "#ef4444",
    "#f97316",
    "#eab308",
    "#22c55e",
    "#06b6d4",
    "#8b5cf6",
    "#ec4899",
    "#14b8a6",
    "#f43f5e",
    "#6366f1",
  ]

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900/90 border-slate-700 backdrop-blur">
        <CardHeader className="pb-3">
          <CardTitle className="text-cyan-400 text-xl">Geo-Spatial Analysis</CardTitle>
          <CardDescription className="text-slate-400">
            High-demand zones, cancellation hotspots & peak-hour patterns across Bangalore
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="heatmap" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-slate-800/80 border border-slate-700 p-1 rounded-lg">
              <TabsTrigger
                value="heatmap"
                className="data-[state=active]:bg-cyan-500 data-[state=active]:text-black rounded-md transition-all"
              >
                Demand Heatmap
              </TabsTrigger>
              <TabsTrigger
                value="cancellations"
                className="data-[state=active]:bg-pink-500 data-[state=active]:text-black rounded-md transition-all"
              >
                Cancellations
              </TabsTrigger>
              <TabsTrigger
                value="scatter"
                className="data-[state=active]:bg-purple-500 data-[state=active]:text-black rounded-md transition-all"
              >
                Geo Scatter
              </TabsTrigger>
            </TabsList>

            <TabsContent value="heatmap" className="mt-6">
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={intensityData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis
                    dataKey="zone"
                    angle={-45}
                    textAnchor="end"
                    height={80}
                    stroke="#94a3b8"
                    tick={{ fontSize: 11, fill: "#94a3b8" }}
                    interval={0}
                  />
                  <YAxis
                    stroke="#94a3b8"
                    tick={{ fill: "#94a3b8" }}
                    label={{ value: "Demand %", angle: -90, position: "insideLeft", fill: "#94a3b8" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #06b6d4",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                    formatter={(value, name) => [
                      name === "intensity" ? `${value}%` : value,
                      name === "intensity" ? "Demand" : "Rides",
                    ]}
                  />
                  <Bar dataKey="intensity" radius={[8, 8, 0, 0]}>
                    {intensityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={getIntensityColor(entry.intensity)} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>

              {/* Zone summary cards */}
              <div className="mt-6 grid grid-cols-2 md:grid-cols-5 gap-3">
                {intensityData.slice(0, 5).map((h, idx) => (
                  <div
                    key={h.zone}
                    className="p-3 bg-slate-800/80 rounded-lg border border-slate-700 hover:border-cyan-500/50 transition-all"
                  >
                    <p className="font-bold text-cyan-400 text-sm truncate">{h.zone}</p>
                    <p className="text-2xl font-black text-white">{h.intensity}%</p>
                    <p className="text-xs text-slate-400">{h.rides.toLocaleString()} rides</p>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="cancellations" className="mt-6">
              <ResponsiveContainer width="100%" height={400}>
                <BarChart
                  data={cancellationByZone}
                  layout="vertical"
                  margin={{ top: 20, right: 30, left: 100, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={true} vertical={false} />
                  <XAxis
                    type="number"
                    stroke="#94a3b8"
                    tick={{ fill: "#94a3b8" }}
                    label={{ value: "Cancellations Count", position: "insideBottom", offset: -10, fill: "#94a3b8" }}
                  />
                  <YAxis
                    dataKey="zone"
                    type="category"
                    width={90}
                    stroke="#94a3b8"
                    tick={{ fontSize: 12, fill: "#94a3b8" }}
                    axisLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #ec4899",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                    formatter={(value, name, props) => {
                      if (name === "cancellations") {
                        return [`${value} cancellations (${props.payload.rate}%)`, "Total"]
                      }
                      return [value, name]
                    }}
                  />
                  <Bar dataKey="cancellations" radius={[0, 8, 8, 0]} barSize={24}>
                    {cancellationByZone.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={index < 3 ? "#ef4444" : index < 6 ? "#f97316" : "#22c55e"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>

              {/* Cancellation insights */}
              <div className="mt-4 p-4 bg-gradient-to-r from-pink-500/10 to-red-500/10 rounded-lg border border-pink-500/30">
                <h4 className="text-pink-400 font-semibold mb-2">Cancellation Hotspots</h4>
                <div className="grid grid-cols-3 gap-4 text-center">
                  {cancellationByZone.slice(0, 3).map((zone, idx) => (
                    <div key={zone.zone}>
                      <p className="text-red-400 text-2xl font-bold">{zone.cancellations}</p>
                      <p className="text-slate-400 text-xs">{zone.zone}</p>
                      <p className="text-slate-500 text-xs">({zone.rate}% rate)</p>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="scatter" className="mt-6">
              <ResponsiveContainer width="100%" height={400}>
                <ScatterChart margin={{ top: 20, right: 30, bottom: 40, left: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis
                    dataKey="x"
                    type="number"
                    domain={[77.5, 77.8]}
                    stroke="#94a3b8"
                    tick={{ fill: "#94a3b8", fontSize: 11 }}
                    label={{ value: "Longitude (°E)", position: "insideBottom", offset: -10, fill: "#94a3b8" }}
                    tickFormatter={(v) => v.toFixed(2)}
                  />
                  <YAxis
                    dataKey="y"
                    type="number"
                    domain={[12.9, 13.25]}
                    stroke="#94a3b8"
                    tick={{ fill: "#94a3b8", fontSize: 11 }}
                    label={{ value: "Latitude (°N)", angle: -90, position: "insideLeft", fill: "#94a3b8" }}
                    tickFormatter={(v) => v.toFixed(2)}
                  />
                  <ZAxis dataKey="z" range={[100, 500]} />
                  <Tooltip
                    cursor={{ strokeDasharray: "3 3", stroke: "#06b6d4" }}
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #8b5cf6",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                    formatter={(value, name, props) => {
                      return null
                    }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload
                        return (
                          <div className="bg-slate-800 p-3 rounded-lg border border-purple-500 text-sm">
                            <p className="font-bold text-purple-400">{data.zone}</p>
                            <p className="text-slate-300">
                              Demand: <span className="text-cyan-400">{data.intensity}%</span>
                            </p>
                            <p className="text-slate-300">
                              Rides: <span className="text-green-400">{data.rides}</span>
                            </p>
                            <p className="text-slate-300">
                              Cancellations: <span className="text-red-400">{data.cancellations}</span>
                            </p>
                          </div>
                        )
                      }
                      return null
                    }}
                  />
                  <Scatter name="Zones" data={scatterData}>
                    {scatterData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={getIntensityColor(entry.intensity)}
                        stroke="#fff"
                        strokeWidth={1}
                      />
                    ))}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>

              {/* Map legend */}
              <div className="mt-4 flex flex-wrap justify-center gap-4 text-xs">
                <span className="flex items-center gap-1">
                  <span className="w-3 h-3 rounded-full bg-red-500"></span> Critical (90%+)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-3 rounded-full bg-orange-500"></span> High (80-89%)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-3 rounded-full bg-yellow-500"></span> Medium (70-79%)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-3 rounded-full bg-green-500"></span> Normal (60-69%)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-3 rounded-full bg-cyan-500"></span> Low (&lt;60%)
                </span>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
