"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function HeatmapVisualization() {
  const [selectedHour, setSelectedHour] = useState(18)

  const zoneBaseData = {
    1: { name: "Koramangala", baseDemand: 75, baseCancelRate: 8, baseRating: 4.7, baseRevenue: 2200 },
    2: { name: "Indiranagar", baseDemand: 82, baseCancelRate: 6, baseRating: 4.8, baseRevenue: 2600 },
    3: { name: "MG Road", baseDemand: 70, baseCancelRate: 12, baseRating: 4.5, baseRevenue: 1800 },
    4: { name: "Whitefield", baseDemand: 65, baseCancelRate: 9, baseRating: 4.6, baseRevenue: 1600 },
    5: { name: "Yelahanka", baseDemand: 55, baseCancelRate: 5, baseRating: 4.9, baseRevenue: 1200 },
    6: { name: "Majestic", baseDemand: 78, baseCancelRate: 15, baseRating: 4.4, baseRevenue: 2100 },
    7: { name: "Hebbal", baseDemand: 60, baseCancelRate: 7, baseRating: 4.7, baseRevenue: 1400 },
    8: { name: "Jayanagar", baseDemand: 58, baseCancelRate: 10, baseRating: 4.6, baseRevenue: 1300 },
    9: { name: "Brookefield", baseDemand: 62, baseCancelRate: 6, baseRating: 4.8, baseRevenue: 1500 },
    10: { name: "Airport", baseDemand: 85, baseCancelRate: 4, baseRating: 4.9, baseRevenue: 3200 },
  }

  const getHourMultipliers = (hour: number) => {
    // Morning rush (7-10)
    if (hour >= 7 && hour <= 10) {
      return { demandMult: 1.35, cancelMult: 1.2, revenueMult: 1.4 }
    }
    // Evening rush (17-20)
    if (hour >= 17 && hour <= 20) {
      return { demandMult: 1.45, cancelMult: 1.35, revenueMult: 1.5 }
    }
    // Late night (22-4)
    if (hour >= 22 || hour <= 4) {
      return { demandMult: 0.5, cancelMult: 1.8, revenueMult: 0.4 }
    }
    // Early morning (5-6)
    if (hour >= 5 && hour <= 6) {
      return { demandMult: 0.7, cancelMult: 0.9, revenueMult: 0.6 }
    }
    // Mid-day (11-16)
    return { demandMult: 0.85, cancelMult: 1.0, revenueMult: 0.8 }
  }

  const zones = useMemo(() => {
    const multipliers = getHourMultipliers(selectedHour)

    return Object.entries(zoneBaseData).map(([id, data]) => {
      // Add some zone-specific hour variations
      const zoneHourVariation = ((Number.parseInt(id) * selectedHour) % 15) - 7

      const demand = Math.min(
        99,
        Math.max(15, Math.round(data.baseDemand * multipliers.demandMult + zoneHourVariation)),
      )
      const cancelRate = Math.min(
        35,
        Math.max(2, Math.round((data.baseCancelRate * multipliers.cancelMult + zoneHourVariation / 3) * 10) / 10),
      )
      const rating = Math.min(5, Math.max(3.5, Math.round((data.baseRating - (cancelRate > 15 ? 0.3 : 0)) * 10) / 10))
      const revenue = Math.round(data.baseRevenue * multipliers.revenueMult + zoneHourVariation * 50)

      return {
        id: Number.parseInt(id),
        name: data.name,
        demand,
        cancellationRate: cancelRate,
        driverRating: rating,
        revenue: Math.max(200, revenue),
      }
    })
  }, [selectedHour])

  const getDemandColor = (demand: number) => {
    if (demand >= 85) return "bg-gradient-to-br from-red-600 to-red-800"
    if (demand >= 70) return "bg-gradient-to-br from-orange-500 to-orange-700"
    if (demand >= 55) return "bg-gradient-to-br from-yellow-500 to-yellow-700"
    if (demand >= 40) return "bg-gradient-to-br from-green-500 to-green-700"
    return "bg-gradient-to-br from-blue-500 to-blue-700"
  }

  const getCancelColor = (rate: number) => {
    if (rate >= 20) return "text-red-400"
    if (rate >= 12) return "text-orange-400"
    return "text-green-400"
  }

  return (
    <div className="space-y-6">
      {/* Hour Slider */}
      <Card className="bg-gray-900/80 border-gray-700 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-cyan-400">Select Time</CardTitle>
          <CardDescription>Choose hour to view demand heatmap - metrics update in real-time</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <input
                type="range"
                min="0"
                max="23"
                value={selectedHour}
                onChange={(e) => setSelectedHour(Number.parseInt(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>12 AM</span>
                <span>6 AM</span>
                <span>12 PM</span>
                <span>6 PM</span>
                <span>11 PM</span>
              </div>
            </div>
            <div className="text-center min-w-[80px]">
              <span className="text-3xl font-bold text-cyan-400">{String(selectedHour).padStart(2, "0")}:00</span>
              <p className="text-xs text-gray-400 mt-1">
                {selectedHour >= 7 && selectedHour <= 10
                  ? "Morning Rush"
                  : selectedHour >= 17 && selectedHour <= 20
                    ? "Evening Rush"
                    : selectedHour >= 22 || selectedHour <= 4
                      ? "Late Night"
                      : "Normal Hours"}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Heatmap Grid */}
      <Card className="bg-gray-900/80 border-gray-700 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-cyan-400">Demand Heatmap by Zone</CardTitle>
          <CardDescription>
            Real-time demand intensity with zone metrics at {String(selectedHour).padStart(2, "0")}:00
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
            {zones.map((zone) => (
              <div
                key={zone.id}
                className={`p-5 rounded-xl ${getDemandColor(zone.demand)} transition-all duration-500 cursor-pointer hover:scale-105 hover:shadow-xl hover:shadow-cyan-500/30 border border-white/10`}
              >
                <p className="text-white font-bold text-base mb-1">{zone.name}</p>
                <p className="text-white text-4xl font-black mb-4">{zone.demand}%</p>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between bg-black/40 p-2 rounded-lg backdrop-blur">
                    <span className="text-gray-200">Cancel Rate:</span>
                    <span className={`font-bold ${getCancelColor(zone.cancellationRate)}`}>
                      {zone.cancellationRate}%
                    </span>
                  </div>
                  <div className="flex justify-between bg-black/40 p-2 rounded-lg backdrop-blur">
                    <span className="text-gray-200">Driver Rating:</span>
                    <span className="font-bold text-yellow-300">★ {zone.driverRating}</span>
                  </div>
                  <div className="flex justify-between bg-black/40 p-2 rounded-lg backdrop-blur">
                    <span className="text-gray-200">Hourly Revenue:</span>
                    <span className="font-bold text-emerald-300">${zone.revenue.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Legend */}
          <div className="mt-8 p-4 bg-gray-800/50 rounded-xl border border-gray-700">
            <p className="text-gray-300 text-sm font-semibold mb-3">Demand Intensity Legend</p>
            <div className="flex items-center gap-6 flex-wrap text-sm">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 bg-gradient-to-br from-red-600 to-red-800 rounded"></div>
                <span className="text-gray-300">Critical (85%+)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 bg-gradient-to-br from-orange-500 to-orange-700 rounded"></div>
                <span className="text-gray-300">High (70-84%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 bg-gradient-to-br from-yellow-500 to-yellow-700 rounded"></div>
                <span className="text-gray-300">Medium (55-69%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 bg-gradient-to-br from-green-500 to-green-700 rounded"></div>
                <span className="text-gray-300">Low (40-54%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 bg-gradient-to-br from-blue-500 to-blue-700 rounded"></div>
                <span className="text-gray-300">Minimal (&lt;40%)</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
