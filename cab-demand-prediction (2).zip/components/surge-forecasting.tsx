"use client"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, AlertCircle } from "lucide-react"

export default function SurgeForecasting() {
  const next24Hours = [
    { hour: 0, multiplier: 1.8, confidence: 0.82, demand: 120 },
    { hour: 3, multiplier: 1.5, confidence: 0.79, demand: 85 },
    { hour: 6, multiplier: 1.2, confidence: 0.75, demand: 45 },
    { hour: 9, multiplier: 1.4, confidence: 0.78, demand: 95 },
    { hour: 12, multiplier: 2.1, confidence: 0.85, demand: 220 },
    { hour: 15, multiplier: 1.9, confidence: 0.83, demand: 195 },
    { hour: 18, multiplier: 1.7, confidence: 0.8, demand: 160 },
    { hour: 21, multiplier: 2.5, confidence: 0.87, demand: 280 },
    { hour: 23, multiplier: 2.2, confidence: 0.84, demand: 240 },
  ]

  const peakWindow = { start: 18, end: 21, maxMultiplier: 2.5 }
  const lowDemandWindow = { start: 2, end: 5, minMultiplier: 1.1 }

  const demandForecast = next24Hours.map((d) => ({ hour: `${d.hour}:00`, demand: d.demand }))
  const confidenceData = next24Hours.map((d) => ({ hour: `${d.hour}:00`, confidence: d.confidence * 100 }))

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-purple-400">Surge Pricing Forecasting</CardTitle>
          <CardDescription className="text-slate-400">
            24-hour predictions using LSTM + ARIMA + Prophet ensemble models
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="surge" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-slate-800 border-slate-700">
              <TabsTrigger
                value="surge"
                className="data-[state=active]:bg-purple-500 data-[state=active]:text-black text-xs"
              >
                Surge Trend
              </TabsTrigger>
              <TabsTrigger
                value="demand"
                className="data-[state=active]:bg-blue-500 data-[state=active]:text-black text-xs"
              >
                Demand
              </TabsTrigger>
              <TabsTrigger
                value="confidence"
                className="data-[state=active]:bg-green-500 data-[state=active]:text-black text-xs"
              >
                Confidence
              </TabsTrigger>
              <TabsTrigger
                value="insights"
                className="data-[state=active]:bg-amber-500 data-[state=active]:text-black text-xs"
              >
                Insights
              </TabsTrigger>
            </TabsList>

            <TabsContent value="surge" className="mt-6">
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={next24Hours}>
                  <defs>
                    <linearGradient id="colorMultiplier" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#a855f7" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="hour" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                    formatter={(value) => `${value.toFixed(2)}x`}
                  />
                  <Area
                    type="monotone"
                    dataKey="multiplier"
                    stroke="#a855f7"
                    fill="url(#colorMultiplier)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
              <div className="mt-4 grid grid-cols-2 gap-4">
                <div className="p-3 bg-slate-800 rounded border border-purple-500/30">
                  <p className="text-xs text-slate-400">Peak Window</p>
                  <p className="text-lg font-bold text-purple-400">
                    {peakWindow.start}:00 - {peakWindow.end}:00
                  </p>
                  <p className="text-sm text-slate-500">Max: {peakWindow.maxMultiplier}x</p>
                </div>
                <div className="p-3 bg-slate-800 rounded border border-green-500/30">
                  <p className="text-xs text-slate-400">Low Demand Window</p>
                  <p className="text-lg font-bold text-green-400">
                    {lowDemandWindow.start}:00 - {lowDemandWindow.end}:00
                  </p>
                  <p className="text-sm text-slate-500">Min: {lowDemandWindow.minMultiplier}x</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="demand" className="mt-6">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={demandForecast}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="hour" stroke="#94a3b8" angle={-45} textAnchor="end" height={80} />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                    formatter={(value) => `${value} rides`}
                  />
                  <Bar dataKey="demand" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </TabsContent>

            <TabsContent value="confidence" className="mt-6">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={confidenceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="hour" stroke="#94a3b8" angle={-45} textAnchor="end" height={80} />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                    formatter={(value) => `${value.toFixed(1)}%`}
                  />
                  <Line
                    type="monotone"
                    dataKey="confidence"
                    stroke="#22c55e"
                    strokeWidth={2}
                    dot={{ fill: "#22c55e" }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </TabsContent>

            <TabsContent value="insights" className="mt-6 space-y-3">
              <div className="p-4 bg-purple-500/10 rounded border border-purple-500/30">
                <div className="flex gap-3">
                  <TrendingUp className="text-purple-400 mt-1" size={20} />
                  <div>
                    <p className="font-semibold text-purple-400">Peak Surge Expected</p>
                    <p className="text-sm text-slate-400">18:00-21:00: Up to 2.5x surge multiplier during rush hour</p>
                  </div>
                </div>
              </div>
              <div className="p-4 bg-green-500/10 rounded border border-green-500/30">
                <div className="flex gap-3">
                  <AlertCircle className="text-green-400 mt-1" size={20} />
                  <div>
                    <p className="font-semibold text-green-400">Best Time to Ride</p>
                    <p className="text-sm text-slate-400">02:00-05:00: Lowest fares with 1.1-1.2x multiplier</p>
                  </div>
                </div>
              </div>
              <div className="p-4 bg-amber-500/10 rounded border border-amber-500/30">
                <div className="flex gap-3">
                  <TrendingUp className="text-amber-400 mt-1" size={20} />
                  <div>
                    <p className="font-semibold text-amber-400">Model Performance</p>
                    <p className="text-sm text-slate-400">LSTM + ARIMA + Prophet ensemble: 85% avg confidence</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
