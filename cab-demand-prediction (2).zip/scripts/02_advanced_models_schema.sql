-- Geo-spatial analysis results
CREATE TABLE IF NOT EXISTS geo_heatmap_data (
  id SERIAL PRIMARY KEY,
  zone_id INTEGER REFERENCES area_zones(zone_id),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  demand_intensity DECIMAL(5, 2),
  cancellation_count INTEGER DEFAULT 0,
  peak_hours TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cancellation prediction model results
CREATE TABLE IF NOT EXISTS cancellation_predictions (
  id SERIAL PRIMARY KEY,
  ride_id INTEGER UNIQUE,
  zone_id INTEGER REFERENCES area_zones(zone_id),
  cancellation_probability DECIMAL(5, 4),
  risk_factors TEXT,
  predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  actual_cancelled BOOLEAN
);

-- Surge pricing forecasting results
CREATE TABLE IF NOT EXISTS surge_forecast (
  id SERIAL PRIMARY KEY,
  zone_id INTEGER REFERENCES area_zones(zone_id),
  forecast_hour TIMESTAMP,
  predicted_surge_multiplier DECIMAL(5, 2),
  confidence_score DECIMAL(5, 4),
  expected_demand INTEGER,
  model_type VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_geo_heatmap_zone ON geo_heatmap_data(zone_id);
CREATE INDEX idx_cancellation_zone ON cancellation_predictions(zone_id);
CREATE INDEX idx_surge_forecast_zone ON surge_forecast(zone_id, forecast_hour);
