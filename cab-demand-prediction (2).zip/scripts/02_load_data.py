import os
import sys
import psycopg2
from psycopg2.extras import execute_values
import pandas as pd
from datetime import datetime
import json

# Get database URL from environment
DATABASE_URL = os.getenv('DATABASE_URL')

if not DATABASE_URL:
    print("Error: DATABASE_URL environment variable not set")
    sys.exit(1)

def connect_db():
    """Create database connection"""
    try:
        conn = psycopg2.connect(DATABASE_URL)
        return conn
    except Exception as e:
        print(f"Database connection error: {e}")
        sys.exit(1)

def load_area_zones(conn, csv_path):
    """Load area zones from CSV"""
    try:
        df = pd.read_csv(csv_path)
        
        # Adjust column names based on actual CSV
        # Expected columns: zone_id, zone_name, latitude, longitude, area_category
        if 'zone_id' not in df.columns:
            df = df.rename(columns={df.columns[0]: 'zone_id'})
        if 'zone_name' not in df.columns and len(df.columns) > 1:
            df = df.rename(columns={df.columns[1]: 'zone_name'})
        
        zones_data = []
        for _, row in df.iterrows():
            zones_data.append((
                int(row['zone_id']) if 'zone_id' in row else int(row[0]),
                str(row.get('zone_name', f"Zone {row.get('zone_id', row[0])}")),
                float(row.get('latitude', 0)),
                float(row.get('longitude', 0)),
                str(row.get('area_category', 'Commercial'))
            ))
        
        with conn.cursor() as cur:
            execute_values(
                cur,
                """INSERT INTO area_zones (zone_id, zone_name, latitude, longitude, area_category)
                   VALUES %s ON CONFLICT (zone_id) DO NOTHING""",
                zones_data
            )
        conn.commit()
        print(f"Loaded {len(zones_data)} area zones")
        
    except Exception as e:
        print(f"Error loading area zones: {e}")
        conn.rollback()

def load_ride_data(conn, csv_path):
    """Load ride data from CSV"""
    try:
        df = pd.read_csv(csv_path)
        
        # Standardize column names
        df.columns = df.columns.str.lower().str.strip()
        
        rides_data = []
        for _, row in df.iterrows():
            try:
                # Parse timestamps
                pickup_time = pd.to_datetime(row.get('pickup_datetime', row.get('pickup_time')))
                dropoff_time = pd.to_datetime(row.get('dropoff_datetime', row.get('dropoff_time'))) if 'dropoff_datetime' in df.columns or 'dropoff_time' in df.columns else None
                
                rides_data.append((
                    int(row.get('pulocationid', row.get('pickup_zone_id', 0))),
                    int(row.get('dolocationid', row.get('dropoff_zone_id', 0))),
                    pickup_time,
                    dropoff_time,
                    float(row.get('fare_amount', row.get('trip_fare', 0))),
                    float(row.get('trip_distance', 0)),
                    int(row.get('passenger_count', 1)),
                    str(row.get('payment_type', 'Credit Card')),
                    float(row.get('surge_multiplier', 1.0))
                ))
            except Exception as e:
                print(f"Skipping row due to error: {e}")
                continue
        
        with conn.cursor() as cur:
            execute_values(
                cur,
                """INSERT INTO ride_data (pickup_zone_id, dropoff_zone_id, pickup_time, dropoff_time, 
                   fare_amount, trip_distance, passenger_count, payment_type, surge_multiplier)
                   VALUES %s""",
                rides_data
            )
        conn.commit()
        print(f"Loaded {len(rides_data)} ride records")
        
    except Exception as e:
        print(f"Error loading ride data: {e}")
        conn.rollback()

if __name__ == "__main__":
    conn = connect_db()
    
    # Check for CSV files in the data directory or use provided paths
    area_zones_path = "data/area_zones.csv"
    ride_data_path = "data/ride_data.csv"
    
    if os.path.exists(area_zones_path):
        load_area_zones(conn, area_zones_path)
    
    if os.path.exists(ride_data_path):
        load_ride_data(conn, ride_data_path)
    
    conn.close()
    print("Data loading complete!")
