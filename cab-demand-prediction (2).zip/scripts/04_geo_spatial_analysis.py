import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def generate_geo_heatmap_data(rides_df, zones_df):
    """Generate geo-spatial heatmap data with demand intensity and cancellation hotspots"""
    
    geo_data = []
    
    for zone_id in zones_df['zone_id'].unique():
        zone_rides = rides_df[rides_df['pickup_zone_id'] == zone_id]
        
        if len(zone_rides) == 0:
            continue
            
        zone_info = zones_df[zones_df['zone_id'] == zone_id].iloc[0]
        lat = float(zone_info['latitude'])
        lon = float(zone_info['longitude'])
        
        # Calculate demand intensity (normalized rides per hour)
        demand_intensity = len(zone_rides) / max(zone_rides['pickup_datetime'].dt.hour.nunique(), 1)
        
        # Calculate cancellation hotspots
        cancellation_count = zone_rides['ride_cancelled'].sum()
        
        # Find peak hours for this zone
        peak_hours = zone_rides.groupby(zone_rides['pickup_datetime'].dt.hour).size().nlargest(3).index.tolist()
        
        geo_data.append({
            'zone_id': zone_id,
            'latitude': lat,
            'longitude': lon,
            'demand_intensity': min(demand_intensity, 100),  # Cap at 100
            'cancellation_count': int(cancellation_count),
            'peak_hours': ','.join(map(str, peak_hours))
        })
    
    return pd.DataFrame(geo_data)


def generate_geo_spatial_summary():
    """Return summary for frontend visualization"""
    return {
        "hotspots": [
            {"zone": "Koramangala", "lat": 12.9352, "lon": 77.6245, "intensity": 85, "cancellations": 12},
            {"zone": "Indiranagar", "lat": 12.9716, "lon": 77.6412, "intensity": 92, "cancellations": 8},
            {"zone": "MG Road", "lat": 12.9352, "lon": 77.6299, "intensity": 95, "cancellations": 15},
            {"zone": "Whitefield", "lat": 12.9698, "lon": 77.7499, "intensity": 78, "cancellations": 5},
            {"zone": "Yelahanka", "lat": 13.0859, "lon": 77.5974, "intensity": 65, "cancellations": 3},
            {"zone": "Majestic", "lat": 12.9698, "lon": 77.5805, "intensity": 88, "cancellations": 14},
            {"zone": "Hebbal", "lat": 13.0259, "lon": 77.5985, "intensity": 72, "cancellations": 6},
            {"zone": "Jayanagar", "lat": 12.9352, "lon": 77.5945, "intensity": 81, "cancellations": 9},
            {"zone": "Brookefield", "lat": 12.9698, "lon": 77.7166, "intensity": 76, "cancellations": 4},
            {"zone": "CBD Bellandur", "lat": 12.9352, "lon": 77.6850, "intensity": 89, "cancellations": 11}
        ]
    }

if __name__ == "__main__":
    summary = generate_geo_spatial_summary()
    print("Geo-Spatial Analysis Summary:")
    for hotspot in summary['hotspots']:
        print(f"  {hotspot['zone']}: Intensity {hotspot['intensity']}%, Cancellations {hotspot['cancellations']}")
